var goodsBehavior = require('../behavior/goods.js');

Component({
  behaviors: [goodsBehavior]
});