// lionfish_comshop/components/cart/index.js
Component({
  options: {
    multipleSlots: true
  },
  externalClasses: ["i-class", "i-card-header", "i-card-body", "i-card-footer"]
})