var goodsBehavior = require('../../components/behavior/goods.js');

Component({
  behaviors: [goodsBehavior]
});